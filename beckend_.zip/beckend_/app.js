const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const Recipe = require('./models/recipe');


// connecting to MongoDB Atlas using installed Mongoose
//
mongoose.connect('mongodb+srv://Denise:9jMsHTIzEodhe4FP@cluster0-id7fc.mongodb.net/test?retryWrites=true',{Denise:true})
  .then(() => {
    console.log('Successfully connected to MongoDB Atlas!');
  })
  .catch((error) => {
    console.log('Unable to connect to MongoDB Atlas!');
    console.error(error);
  });


// middleware to allow all requests from all origins to access the API
//Headers that allows localhost:3000 and localhost:4200 to be able to communicate with each other
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content, Accept, Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
  next();
});


//
app.use(bodyParser.json());


// Saving (Post) recipes to the database
app.post('/api/recipes', (req, res, next) => {
  const recipe = new Recipe({
    title: req.body.title,
    ingredients: req.body.ingredients,
    instructions: req.body.instructions,
    difficulty: req.body.difficulty,
    time: req.body.time
  });
  recipe.save().then(
    () => {
      res.status(201).json({
        message: 'Post saved successfully!'
      });
    }
  ).catch(
    (error) => {
      res.status(400).json({
        error: error
      });
    }
  );
});



//Retrieving a specific recipe route
app.get('/api/recipes/:id', (req, res, next) => {
  Recipe.findOne({
    _id: req.params.id
  }).then(
    (recipe) => {
      res.status(200).json(recipe);
    }
  ).catch(
    (error) => {
      res.status(404).json({
        error: error
      });
    }
  );
});


// Updating recipe Route
app.put('/api/recipes/:id', (req, res, next) => {
  const recipe = new Recipe({
    _id: req.params.id,
    title: req.body.title,
    ingredients: req.body.ingredients,
    instructions: req.body.instructions,
    difficulty: req.body.difficulty,
    time: req.body.time

  });
  Recipe.updateOne({_id: req.params.id}, recipe).then(
    () => {
      res.status(201).json({
        message: 'Recipe updated successfully!'
      });
    }
  ).catch(
    (error) => {
      res.status(400).json({
        error: error
      });
    }
  );
});


// Deleting Recipe Route
app.delete('/api/recipes/:id', (req, res, next) => {
  Recipe.deleteOne({_id: req.params.id}).then(
    () => {
      res.status(200).json({
        message: 'Recipe Deleted!'
      });
    }
  ).catch(
    (error) => {
      res.status(400).json({
        error: error
      });
    }
  );
});

//Retrieving the list of all recipes in database
app.use('/api/recipes', (req, res, next) => {
  Recipe.find().then(
    (recipes) => {
      res.status(200).json(recipes);
    }
  ).catch(
    (error) => {
      res.status(400).json({
        error: error
      });
    }
  );
});

// //Manual Get recipes Route (don't work)
// app.use('/api/recipes', (req, res, next) => {
//   const recipe = [
//     {
//       title: 'Tomato Paste',
//       ingredients: ['Tomatoes','Water', 'Salt'],
//       instructions: 'Mix tomatoes with salt.',
//       difficulty: 4,
//       time: 50,
//       _id: 'Inyanya',
//     },
//     {
//       title: 'Cube Maggi',
//       ingredients: 'Salt',
//       instructions: 'Mix of salt and Maggi',
//       difficulty: 5,
//       time: 12,
//       _id: 'Maggi',
//     },
//   ];
//   res.status(200).json(recipe);
// });


// Exporting this app for outside usage
module.exports = app;